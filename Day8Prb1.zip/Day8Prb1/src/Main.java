import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.hibernate.Session;

public class Main {
    static BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) throws NumberFormatException, IOException, ParseException {
		Logger log = Logger.getLogger("org.hibernate");
    	log.setLevel(Level.OFF);
    	System.setProperty("org.apache.commons.logging.Log","org.apache.commons.logging.impl.NoOpLog");
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		StallBO stallBO = new StallBO();
		Stall stall =new Stall();
		do {
			System.out.println("Menu");
			System.out.println("1.Stall Registration");
			System.out.println("2.Stall Licensing");
			System.out.println("3.Show stalls");
			System.out.println("4.Exit");
			System.out.println("Enter choice");
			switch(Integer.parseInt(br.readLine())) {
			case 1:
				System.out.println("Enter stall id");
				stall.setStallId(Integer.parseInt(br.readLine()));
				System.out.println("Enter stall name");
				stall.setName( br.readLine());
				System.out.println("Enter stall type");
				stall.setType(br.readLine());
				
				stallBO.registerStall(stall);
				
				break;
				
			case 2:
				
				System.out.println("Enter license id");
				Integer LicenseId = Integer.parseInt(br.readLine());
				System.out.println("Enter expiry date");
				Date ExpiryDate = sdf.parse(br.readLine());
				System.out.println("Enter stall id");
				Integer stallId2 = Integer.parseInt(br.readLine());
				
				Stall stall1 = stallBO.findStallById(stallId2);
				if(stall==null) {
					System.out.println("Stall not found");
					break;
				}else {
					/*
					 * StallLicense license = new StallLicense(LicenseId, ExpiryDate,stall);
					 * stall.setLicense(license); stallBO.getLicense(stall);
					 */
					
					  StallLicense license = new StallLicense(LicenseId, ExpiryDate);
					  stall.setLicense(license); 
					  stallBO.getLicense(stall);;
					 
				}
				break;
			case 3:
				System.out.printf("%-15s %-15s %-15s %s\n","Stall id","Name","Type","License(Expiry)"); 
				List list=stallBO.listStalls();
				
				  for(Object o:list)
				  { 
					  stall=(Stall)o; 
					  if(stall.getLicense()==null)
				  System.out.printf("%-15s %-15s %-15s %s\n",stall.getStallId(),stall.getName(),stall.getType(),"Not applied");
					  else
				  System.out.printf("%-15s %-15s %-15s %s\n",stall.getStallId(),stall.getName(),stall.getType(),stall.getLicense().getLicenseId()+"("+sdf.format(stall.getLicense().getExpiryDate())+")"); 
					  }
				 
				break;
			case 4:
				System.exit(0);
			default:
				System.out.println("Invalid choice");
			}
		}while(true);
	}
}