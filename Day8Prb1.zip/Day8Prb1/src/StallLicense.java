	import java.io.Serializable;
	import java.util.Date;
	
	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.Id;
	import javax.persistence.JoinColumn;
	import javax.persistence.OneToOne;
	import javax.persistence.Table;
	
	@Entity
	@Table
	public class StallLicense implements Serializable{
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		@Id
		@GeneratedValue
		@Column
		Integer licenseId;
		@Column
		Date expiryDate;
		
		@OneToOne
		@JoinColumn(name ="stallId")
		Stall stall;
		
	
	  public StallLicense(Integer licenseId, Date expiryDate) { 
		 super();
		 this.licenseId = licenseId; this.expiryDate = expiryDate; 
	  }
	 
		
	/*
	 * public StallLicense(Integer licenseId, Date expiryDate, Stall stall) {
	 * super(); this.licenseId = licenseId; this.expiryDate = expiryDate; this.stall
	 * = stall; }
	 */
		
		public Integer getLicenseId() {
			return licenseId;
		}
		public void setLicenseId(Integer licenseId) {
			this.licenseId = licenseId;
		}
		public Date getExpiryDate() {
			return expiryDate;
		}
		public void setExpiryDate(Date expiryDate) {
			this.expiryDate = expiryDate;
		}
		public Stall getStall() {
			return stall;
		}
		public void setStall(Stall stall) {
			this.stall = stall;
		}
	}


