import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;

public class StallDAO {
	Session session = HibernateUtil.getSessionFactory().openSession();
	
	public void insert(Stall stall) {
	Transaction tr = session.beginTransaction();
	session.save(stall);
	tr.commit();
	System.out.println("Stall added");
	}
	
	
	public Stall find(int id) {
		 Stall stall =(Stall) session.get(Stall.class, id);
		return stall;
	}
	public void update(Stall stall) {
        Transaction tr=session.beginTransaction();
        session.update(stall);
        tr.commit();
	}
	@SuppressWarnings("unchecked")
	public List<Stall> list() {
		return session.createCriteria(Stall.class).addOrder(Order.asc("stallId")).list();
		
	}
}
