import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {
	static BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) throws NumberFormatException, IOException {
		Logger log = Logger.getLogger("org.hibernate");
    	log.setLevel(Level.OFF);
    	System.setProperty("org.apache.commons.logging.Log","org.apache.commons.logging.impl.NoOpLog");
    	UserDAO userDAO = new UserDAO();
		System.out.println("Enter no. of users");
		 int no =Integer.parseInt(br.readLine());
		 for(int i=0;i<no;i++){
			 User user=new User();
	         System.out.println("Enter name of user "+(i+1));
	         	user.setName(br.readLine());
	         System.out.println("Enter phone number of user "+(i+1));
	            user.setPhoneNumber(Long.parseLong(br.readLine()));
	         System.out.println("Enter user id of user "+(i+1));
	             user.setUserId(br.readLine());
	         System.out.println("Enter password of user "+(i+1));
	             user.setPassword(br.readLine());
	             
	       userDAO.insert(user);
	     }
		 
		 List<User> userList=userDAO.list();
		 
		  System.out.println("User Details");
	      System.out.printf("%-15s %-15s %s\n","Name","Phone number","User id");
	         for(User user:userList){
	             System.out.printf("%-15s %-15s %s\n",user.getName(),user.getPhoneNumber(),String.valueOf(user.getUserId()));
	          }
	
	}
}
