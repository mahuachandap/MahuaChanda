
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class UserDAO {
	public void insert(User user) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session s = sessionFactory.openSession();
		Transaction tr = null;
		try{
		System.out.println("Inside insert");	
		tr = s.beginTransaction();
		s.save(user);//inserting user
		tr.commit();
		System.out.println("After commit");
		}catch(Exception e){
			e.printStackTrace();
			//tr.rollback();
			
		}
	}
	
	public List<User> list(){
		
		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
        Session s= sessionFactory.openSession();
        Transaction tr=null;
        List<User>list=new ArrayList<User>();
        try{
        	tr=s.beginTransaction();
        	list=s.createCriteria(User.class).list();
        	tr.commit();
        	
        }catch(Exception e){
            e.printStackTrace();
            tr.rollback();
        }
        s.close();
        return list;
		
	}
}
